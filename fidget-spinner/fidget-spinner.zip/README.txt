NOTE: This theme is made as a joke, don't take it seriously.
You can thank Alex4U for that.
Made by B_E_P_I_S_M_A_N.